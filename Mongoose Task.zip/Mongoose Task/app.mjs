const User = import('../models/User');


export const getProducts = async (req, res) => {
    try {
        const products = await User.find();
        res.status(200).json(products);
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
};

export const addProduct = async (req, res) => {
    const productData = req.body;

    const newProduct = new User(productData);
    try {
        await newProduct.save();
        res.status(201).json(newProduct);
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
};

export const editProduct = async (req, res) => {
    const updatedProductData = req.body;

    try {
        await User.updateOne({ _id: req.params.id }, updatedProductData);
        res.status(200).json(updatedProductData);
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
};

export const deleteProduct = async (req, res) => {
    try {
        await User.deleteOne({ _id: req.params.id });
        res.status(200).json({ message: 'Product deleted successfully' });
    } catch (error) {
        res.status(409).json({ message: error.message });
    }
};
